int main() {
    // Insert some test entries
    bool insertSuccess = insertEntry("Alice", 123);
    std::cout << "Insert Alice: " << (insertSuccess ? "Success" : "Failed") << std::endl;

    insertSuccess = insertEntry("Bob", 456);
    std::cout << "Insert Bob: " << (insertSuccess ? "Success" : "Failed") << std::endl;

    insertSuccess = insertEntry("Charlie", 789);
    std::cout << "Insert Charlie: " << (insertSuccess ? "Success" : "Failed") << std::endl;

    // Attempt to insert a duplicate key to test update functionality
    insertSuccess = insertEntry("Alice", 999);
    std::cout << "Re-insert Alice with new value: " << (insertSuccess ? "Success" : "Failed") << std::endl;

    // Optionally, print the hash table state to visually inspect the result
    for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
        if (hashTable[i].has_value()) {
            std::cout << "Slot " << i << ": " << hashTable[i]->key << ", " << hashTable[i]->value << std::endl;
        }
    }

    return 0;
}

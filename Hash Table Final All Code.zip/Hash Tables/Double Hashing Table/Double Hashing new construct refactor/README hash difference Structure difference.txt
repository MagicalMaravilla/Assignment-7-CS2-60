Function-Based Approach:

- h1 and h2 are standalone functions.

- h1 generates a hash value by summing the ascii values of the characters in the key and then taking the modulo with hash_size_table.

- h2 generates a secondary hash which is a prime number R minus the modulo of the sum of ascii values of the key's characters and R. The purpose of h2 is to provide a second probe sequence that is relatively prime to the table size, which helps in evenly distributing keys and resolving collisions.

- doubleHashing combines these two hash functions by adding hash1 and hash2 multiplied by the number of attempts. This function is then modulo by hash_size_table to ensure it falls within the hash table bounds.



Class-Based Approach:

-HashFunction is a class that encapsulates the hashing logic, making it a reusable component.

-It has R as a static member, serving a similar purpose as in the first snippet.

-The operator() is defined to work similarly to the doubleHashing function in the first snippet, combining hash1 and hash2 within the bounds of tableSize.

- hashFunction is analogous to h1, providing the primary hash by summing up the ascii values and taking the modulo with tableSize.

- secondaryHash mirrors h2, offering an alternative probe sequence using a prime number R.


Differences:

- Encapsulation: The first approach defines hashing as individual functions, whereas the second approach encapsulates hashing within a HashFunction class.

- Reusability and Flexibility: The class-based approach allows for more flexibility and reusability of the hashing logic, as it can be used with different table sizes without modifying the functions themselves.

- Member Accessibility: In the class-based approach, hashFunction and secondaryHash are private, meaning they cannot be accessed outside of HashFunction methods, enforcing encapsulation and potentially reducing the likelihood of misuse.

Similarities:

- Hashing Algorithm: Both use double hashing, which uses two hash functions to calculate an index for a given key.

- Prime Number: They both utilize a prime number to generate a secondary hash, which is critical for the use of double hashing.

-Final Index Calculation: In both cases, the final index for insertion into the hash table is calculated using a combination of the results from h1/hashFunction and h2/secondaryHash along with the attempt number.

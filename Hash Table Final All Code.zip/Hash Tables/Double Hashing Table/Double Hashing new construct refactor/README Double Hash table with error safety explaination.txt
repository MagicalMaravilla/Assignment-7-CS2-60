Efficiency of Hash function: Even though my earlier tests without hash function were slower than my final code, the introduction of double hash has improved speeds. From a simple insertion test taking over 1 second. To resizing, and filling tables repetitivly, and finishing the test in about .6 to .7ish seconds.

Output handling: Both versions output to the console when an error occurs the robust version throws exceptions that are caught and printed, while the simpler version prints errors directly. Console output is a relatively slow operation compared to in-memory operations, and if it's the primary action performed when handling errors, it can bottleneck runtimes.

Error frequency: The runtime shows the success of the robust error handling, less errors means  quicker run times.

Stress Tests: In the stress tests, most of the time is spent doing successful operations. The "table is full" error that appears only happens after the table has been filled, which means it doesnt affect the runtime until the end of the test.

Error handling implementations: in my error handling version, exceptions are used, but if the catch blocks, print the errror message similar to the simple version of code using std::cerr

Final Thoughts: The similar performance between the two versions during testing is probably the console output operations being the primary time-consuming factor, it overshadows the differences in error handling, however the simple version would fail these tests quiet fast in a real world scenario. The actual insertion logic, which is the same in both cases, is the main determinant of performance until the hash table is filled. I could see how having Username and password retrevial, or any other information like a giant library with books and book IDs.





//insert only test function

void printHashTable() {
    for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
        std::cout << "Slot " << i << ": ";
        for (const auto& entry : hashTable[i]) {
            std::cout << "[" << entry.studentName << ", " << entry.assignedNumber << "] ";
        }
        std::cout << std::endl;
    }
}

int main() {
    // Insert some test entries
    insertEntry("Alice", 1);
    insertEntry("Bob", 2);
    insertEntry("Charlie", 3);
    insertEntry("David", 4);
    insertEntry("Eve", 5);

    // Print the contents of the hash table to verify the insertion
    printHashTable();

    return 0;
}
// 
int main() {
    // Insert some entries
    insertEntry("Alice", 1);
    insertEntry("Bob", 2);
    insertEntry("Charlie", 3);

    // Test searching for an existing name
    std::string searchName = "Alice";
    int foundNumber = searchStudent(searchName);
    if (foundNumber != -1) {
        std::cout << "Found " << searchName << " with number " << foundNumber << "." << std::endl;
    } else {
        std::cout << searchName << " not found." << std::endl;
    }

    // Test searching for a non-existing name
    searchName = "Diana";
    foundNumber = searchStudent(searchName);
    if (foundNumber != -1) {
        std::cout << "Found " << searchName << " with number " << foundNumber << "." << std::endl;
    } else {
        std::cout << searchName << " not found, returned " << foundNumber << "." << std::endl;
    }

    return 0;
}

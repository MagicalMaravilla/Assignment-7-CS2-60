#include <list>
#include <string>
#include <iostream>

// Step 1: Define the Entry Structure
struct HashTableEntry {
    std::string studentName; // The key
    int assignedNumber;      // The value

    // Constructor for convenience
    HashTableEntry(const std::string& name, int number) : studentName(name), assignedNumber(number) {}
};

// Step 2: Define the Hash Table
const int HASH_TABLE_SIZE = 10;
std::list<HashTableEntry> hashTable[HASH_TABLE_SIZE];

int hashFunction(const std::string& key) {
    int sum = 0;
    // Summing the ASCII values of the characters in the key
    for(char c : key) {
        sum += static_cast<int>(c);
    }
    // Applying modulo 10 to ensure it falls within our hash table slots
    return sum % HASH_TABLE_SIZE;
}

void insertEntry(const std::string& name, int number) {
    // Create a new HashTableEntry
    HashTableEntry newEntry(name, number);

    // Use the hash function to determine the slot index
    int index = hashFunction(name);

    // Append the new entry to the list in the corresponding slot
    // Since each slot is a std::list, we can directly push_back the new entry
    hashTable[index].push_back(newEntry);
}

int searchStudent(const std::string& name) {
    // Use the hash function to find the slot index
    int index = hashFunction(name);

    // Search through the list at this slot
    for (const auto& entry : hashTable[index]) {
        if (entry.studentName == name) {
            // If an entry with the matching name is found, return the assigned number
            return entry.assignedNumber;
        }
    }

    // If not found, you might want to indicate this somehow. For simplicity, we'll return -1.
    // In real applications, you might throw an exception or use std::optional<int> for a safer approach.
    return -1;
}

bool deleteStudent(const std::string& name) {
    // Use the hash function to find the slot index
    int index = hashFunction(name);

    // Iterate through the list at this slot to find the entry with the matching name
    for (auto it = hashTable[index].begin(); it != hashTable[index].end(); ++it) {
        if (it->studentName == name) {
            // If an entry with the matching name is found, remove it
            hashTable[index].erase(it);
            return true; // Return true to indicate successful deletion
        }
    }

    // If the function reaches this point, the entry was not found
    return false; // Return false to indicate that the deletion was unsuccessful
}

void printHashTable() {
    std::cout << "Current Hash Table State:" << std::endl;
    for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
        std::cout << "Slot " << i << ": ";
        for (const auto& entry : hashTable[i]) {
            std::cout << "[" << entry.studentName << ", " << entry.assignedNumber << "] ";
        }
        std::cout << std::endl;
    }
}

int main() {
    // Insert some entries
    insertEntry("Alice", 1);
    insertEntry("Bob", 2);
    insertEntry("Charlie", 3);
    insertEntry("Diana", 4);

    // Search for an existing entry
    std::cout << "Searching for Bob: " << searchStudent("Bob") << std::endl;
    // Search for a non-existing entry
    std::cout << "Searching for Zach: " << searchStudent("Zach") << std::endl;

    // Delete an existing entry
    if (deleteStudent("Charlie")) {
        std::cout << "Charlie was successfully deleted." << std::endl;
    } else {
        std::cout << "Charlie was not found to delete." << std::endl;
    }

    // Attempt to delete a non-existing entry
    if (deleteStudent("Zach")) {
        std::cout << "Zach was successfully deleted." << std::endl;
    } else {
        std::cout << "Zach was not found to delete." << std::endl;
    }

    // Search for an entry that was deleted to confirm it's no longer there
    std::cout << "Searching for Charlie after deletion: " << searchStudent("Charlie") << std::endl;

    // Print the hash table's current state to visually confirm the deletion
    printHashTable();

    return 0;
}

#include <vector>
#include <optional>
#include <string>
#include <iostream>

struct HashTableEntry {
    std::string key;
    int value;
    HashTableEntry(const std::string& key, int value) : key(key), value(value) {}
};

int hashTableSize = 100;
std::vector<std::optional<HashTableEntry>> hashTable(hashTableSize);
int totalEntries = 0;

int h1(const std::string& key) {
    int hashValue = 0;
    for (char c : key) {
        hashValue += static_cast<int>(c);
    }
    return hashValue % hashTableSize;
}

const int R = 97;

int h2(const std::string& key) {
    int hashValue = 0;
    for (char c : key) {
        hashValue += static_cast<int>(c);
    }
    return R - (hashValue % R);
}

int doubleHashing(const std::string& key, int attempt) {
    int hash1 = h1(key);
    int hash2 = h2(key);
    return (hash1 + attempt * hash2) % hashTableSize;
}

void rehash(std::vector<std::optional<HashTableEntry>>& newHashTable) {
    for (int i = 0; i < hashTable.size(); ++i) {
        if (hashTable[i].has_value()) {
            HashTableEntry entry = hashTable[i].value();
            int attempt = 0;
            while (attempt < hashTableSize) {
                int newIndex = doubleHashing(entry.key, attempt);
                if (!newHashTable[newIndex].has_value()) {
                    newHashTable[newIndex] = entry;
                    break;
                }
                attempt++;
            }
        }
    }
}

void resizeHashTable() {
    int oldSize = hashTableSize;
    hashTableSize *= 2;
    std::vector<std::optional<HashTableEntry>> newHashTable(hashTableSize);
    rehash(newHashTable);
    hashTable = std::move(newHashTable);
}

bool insertEntry(const std::string& key, int value) {
    if (totalEntries >= hashTableSize * 0.75) { // Resize before hitting the critical load factor
        resizeHashTable();
    }
    int attempt = 0;
    while (attempt < hashTableSize) {
        int newIndex = doubleHashing(key, attempt);
        if (!hashTable[newIndex].has_value() || hashTable[newIndex]->key == key) {
            hashTable[newIndex] = HashTableEntry(key, value);
            totalEntries++;
            return true;
        }
        attempt++;
    }
    return false; // Should be less likely to occur with earlier resizing
}

std::optional<int> searchEntry(const std::string& key) {
    int attempt = 0;
    while (attempt < hashTableSize) {
        int newIndex = doubleHashing(key, attempt);
        if (!hashTable[newIndex].has_value()) {
            return std::nullopt;
        } else if (hashTable[newIndex]->key == key) {
            return hashTable[newIndex]->value;
        }
        attempt++;
    }
    return std::nullopt;
}

bool deleteEntry(const std::string& key) {
    int attempt = 0;
    while (attempt < hashTableSize) {
        int newIndex = doubleHashing(key, attempt);
        if (!hashTable[newIndex].has_value()) {
            return false;
        } else if (hashTable[newIndex]->key == key) {
            hashTable[newIndex].reset();
            totalEntries--;
            return true;
        }
        attempt++;
    }
    return false;
}

void testHashTable() {
    std::cout << "Insertion Test\n";
    for (int i = 0; i < 150; ++i) {
        insertEntry("Student" + std::to_string(i), i);
    }

    std::cout << "Current hash table size: " << hashTableSize << "\n";

    std::cout << "Search Test\n";
    auto searchResult = searchEntry("Student50");
    std::cout << "Searching for Student50: " << (searchResult.has_value() ? std::to_string(searchResult.value()) : "Not Found") << std::endl;

    std::cout << "Deletion Test\n";
    if (deleteEntry("Student50")) {
        std::cout << "Student50 deleted successfully.\n";
    }
    searchResult = searchEntry("Student50");
    std::cout << "Searching for Student50 after deletion: " << (searchResult.has_value() ? std::to_string(searchResult.value()) : "Not Found") << std::endl;
}

int main() {
    testHashTable(); // Demonstrates functionality and dynamic resizing.
    return 0;
}
